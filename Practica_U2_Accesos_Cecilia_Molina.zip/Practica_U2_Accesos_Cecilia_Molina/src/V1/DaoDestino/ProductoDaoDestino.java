package V1.DaoDestino;

/**
 * Esta clase realiza/se encarga de comunicarse con mysql ….
 *
 * @author Cecilia Molina García
 */
import V1.Conexión.ConnectionFactoryDestino;
import V1.model.ProductoMigra;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ProductoDaoDestino {

    private static final String SQL_INSERT =
            "INSERT INTO productos_migra (nombre_migra, precio_migra, migrado_migra) VALUES (?,?,?)";

    public void insertar(ProductoMigra producto) {

        try (Connection con = ConnectionFactoryDestino.getConnection();
             PreparedStatement ps = con.prepareStatement(SQL_INSERT)) {

            ps.setString(1, producto.getNombre());
            ps.setBigDecimal(2, producto.getPrecio());
            ps.setBoolean(3, producto.isMigrado());

            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
