package V1.DaoDestino;

/**
 * Esta clase realiza/se encarga de comunicarse con mysql ….
 *
 * @author Cecilia Molina García
 */

import V1.Conexión.ConnectionFactoryDestino;
import V1.model.PedidoMigra;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PedidoDaoDestino {

    private static final String SQL_INSERT =
            "INSERT INTO pedidos_migra (cliente_id_migra, producto_id_migra, cantidad_migra, fecha_migra, migrado_migra) " +
                    "VALUES (?,?,?,?,?)";

    public void insertar(PedidoMigra pedido) {

        try (Connection con = ConnectionFactoryDestino.getConnection();
             PreparedStatement ps = con.prepareStatement(SQL_INSERT)) {

            ps.setInt(1, pedido.getClienteId());
            ps.setInt(2, pedido.getProductoId());
            ps.setInt(3, pedido.getCantidad());
            ps.setDate(4, pedido.getFecha());
            ps.setBoolean(5, pedido.isMigrado());

            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
