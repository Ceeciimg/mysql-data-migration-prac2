package V1.DaoDestino;

/**
 * Esta clase realiza/se encarga de comunicarse con mysql ….
 *
 * @author Cecilia Molina García
 */

import V1.Conexión.ConnectionFactoryDestino;
import V1.model.ClienteMigra;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ClienteDaoDestino {

    private static final String SQL_INSERT =
            "INSERT INTO clientes_migra (nombre_migra, email_migra, telefono_migra, direccion_migra, migrado_migra) " +
                    "VALUES (?,?,?,?,?)";

    public void insertar(ClienteMigra cliente) {

        try (Connection con = ConnectionFactoryDestino.getConnection();
             PreparedStatement ps = con.prepareStatement(SQL_INSERT)) {

            ps.setString(1, cliente.getNombre());
            ps.setString(2, cliente.getEmail());
            ps.setString(3, cliente.getTelefono());
            ps.setString(4, cliente.getDireccion());
            ps.setBoolean(5, cliente.isMigrado());

            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
