package V1.Migración;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Esta clase realiza/se encarga de migrar los datos ….
 *
 * @author Cecilia Molina García
 */

import V1.DaoDestino.ClienteDaoDestino;
import V1.DaoDestino.PedidoDaoDestino;
import V1.DaoDestino.ProductoDaoDestino;
import V1.DaoOrigen.ClienteDaoOrigen;
import V1.DaoOrigen.PedidoDaoOrigen;
import V1.DaoOrigen.ProductoDaoOrigen;
import V1.model.*;

import java.util.List;

public class MainMigracion {

    private static final Logger logger = Logger.getLogger(MainMigracion.class.getName());

    public static void main(String[] args) {

        logger.info("INICIANDO PROCESO DE MIGRACIÓN");

        try {

            //  DAO ORIGEN
            ClienteDaoOrigen clienteOrigen = new ClienteDaoOrigen();
            ProductoDaoOrigen productoOrigen = new ProductoDaoOrigen();
            PedidoDaoOrigen pedidoOrigen = new PedidoDaoOrigen();

            //  DAO DESTINO
            ClienteDaoDestino clienteDestino = new ClienteDaoDestino();
            ProductoDaoDestino productoDestino = new ProductoDaoDestino();
            PedidoDaoDestino pedidoDestino = new PedidoDaoDestino();

            // 1 MIGRAR CLIENTES

            logger.info("Migrando clientes...");

            List<Cliente> listaClientes = clienteOrigen.obtenerTodos();
            logger.info("Clientes obtenidos de origen: " + listaClientes.size());

            for (Cliente cliente : listaClientes) {
                ClienteMigra cm = new ClienteMigra(
                        0,
                        cliente.getNombre(),
                        cliente.getEmail(),
                        cliente.getTelefono(),
                        cliente.getDireccion(),
                        true
                );
                clienteDestino.insertar(cm);
                logger.fine("Cliente migrado: " + cliente.getNombre());
            }

            logger.info("Clientes migrados correctamente: " + listaClientes.size());


            // 2 MIGRAR PRODUCTOS

            System.out.println("Migrando productos...");

            List<Producto> listaProductos = productoOrigen.obtenerTodos();
            logger.info("Productos obtenidos de origen: " + listaProductos.size());


            for (Producto producto : listaProductos) {
                ProductoMigra pm = new ProductoMigra(
                        0,
                        producto.getNombre(),
                        producto.getPrecio(),
                        true
                );
                productoDestino.insertar(pm);
                logger.fine("Producto migrado: " + producto.getNombre());
            }
            System.out.println("Productos migrados correctamente");



            // 3 MIGRAR PEDIDOS

            logger.info("Migrando pedidos...");

            List<Pedido> listaPedidos = pedidoOrigen.obtenerTodos();

            for (Pedido pedido : listaPedidos) {
                PedidoMigra pm = new PedidoMigra(
                        0,
                        pedido.getClienteId(),
                        pedido.getProductoId(),
                        pedido.getCantidad(),
                        pedido.getFecha(),
                        true
                );
                pedidoDestino.insertar(pm);
            }

            logger.info("Productos obtenidos de origen: " + listaProductos.size());


            System.out.println(" MIGRACIÓN COMPLETADA CON ÉXITO ");

        } catch (Exception e) {

            logger.log(Level.SEVERE, "Error durante la migración: " + e.getMessage(), e);
        }
    }

}

