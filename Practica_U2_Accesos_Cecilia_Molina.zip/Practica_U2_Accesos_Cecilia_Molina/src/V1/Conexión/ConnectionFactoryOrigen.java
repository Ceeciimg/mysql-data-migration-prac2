package V1.Conexión;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Esta clase realiza/se encarga de realizar la conexión a la base de datos de origen (de donde salen los datos) ….
 *
 * @author Cecilia Molina García
 */

public class ConnectionFactoryOrigen {

    private static final String URL = "jdbc:mysql://localhost:3306/prac2";
    private static final String USER = "root";
    private static final String PASS = "Cecilia.200";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }
}
