package V1.Conexión;

import java.sql.Connection;

/**
 * Esta clase realiza/se encarga de comprobar si se ha realizado la conexión correctamente a las 2 bases de datos ….
 *
 * @author Cecilia Molina García
 */

public class TestConexion {

    public static void main(String[] args) {
        try {
            Connection con1 = ConnectionFactoryOrigen.getConnection();
            System.out.println("Conexión a prac2 CORRECTAMENTE");

            Connection con2 = ConnectionFactoryDestino.getConnection();
            System.out.println("Conexión a prac2migra CORRECTAMENTE");

        } catch (Exception e) {
            System.out.println("error de conexión: " + e.getMessage());
        }
    }
}

