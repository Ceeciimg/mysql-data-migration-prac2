package V1.DaoOrigen;

/**
 * Esta clase realiza/se encarga de comunicarse con mysql ….
 *
 * @author Cecilia Molina García
 */
import V1.Conexión.ConnectionFactoryOrigen;
import V1.model.Cliente;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ClienteDaoOrigen {

    public List<Cliente> obtenerTodos() {

        List<Cliente> lista = new ArrayList<>();

        String sql = "SELECT id, nombre, email, telefono, direccion FROM clientes";

        try (Connection con = ConnectionFactoryOrigen.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Cliente cliente = new Cliente(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("email"),
                        rs.getString("telefono"),
                        rs.getString("direccion")
                );
                lista.add(cliente);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }


}
