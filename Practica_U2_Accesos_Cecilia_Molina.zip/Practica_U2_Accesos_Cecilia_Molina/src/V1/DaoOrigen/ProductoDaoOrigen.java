package V1.DaoOrigen;

/**
 * Esta clase realiza/se encarga de comunicarse con mysql ….
 *
 * @author Cecilia Molina García
 */
import V1.Conexión.ConnectionFactoryOrigen;
import V1.model.Producto;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProductoDaoOrigen {

    public List<Producto> obtenerTodos() {

        List<Producto> lista = new ArrayList<>();

        String sql = "SELECT id, nombre, precio, categoria FROM productos";

        try (Connection con = ConnectionFactoryOrigen.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Producto producto = new Producto(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getBigDecimal("precio"),
                        rs.getString("categoria")
                );
                lista.add(producto);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
}
