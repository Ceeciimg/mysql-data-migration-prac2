package V1.DaoOrigen;
import V1.Conexión.ConnectionFactoryOrigen;
import V1.model.Pedido;

/**
 * Esta clase realiza/se encarga de comunicarse con mysql ….
 *
 * @author Cecilia Molina García
 */

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PedidoDaoOrigen {

    public List<Pedido> obtenerTodos() {

        List<Pedido> lista = new ArrayList<>();

        String sql = "SELECT id, cliente_id, producto_id, cantidad, fecha FROM pedidos";

        try (Connection con = ConnectionFactoryOrigen.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Pedido pedido = new Pedido(
                        rs.getInt("id"),
                        rs.getInt("cliente_id"),
                        rs.getInt("producto_id"),
                        rs.getInt("cantidad"),
                        rs.getDate("fecha")
                );
                lista.add(pedido);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
}
