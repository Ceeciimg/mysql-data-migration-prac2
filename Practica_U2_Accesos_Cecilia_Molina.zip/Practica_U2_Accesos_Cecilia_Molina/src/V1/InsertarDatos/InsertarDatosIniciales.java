package V1.InsertarDatos;
import V1.Conexión.ConnectionFactoryOrigen;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Esta clase realiza/se encarga de insertar datos de origen en la base de datos prac2 para luego migrarlos ….
 *
 * @author Cecilia Molina García
 */


public class InsertarDatosIniciales {

    public static void main(String[] args) {

        try (Connection con = ConnectionFactoryOrigen.getConnection()) {

            insertarClientes(con);
            insertarProductos(con);
            insertarPedidos(con);

            System.out.println("Datos insertados correctamente en prac2.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    // INSERTAR 50 CLIENTES


    private static void insertarClientes(Connection con) throws SQLException {

        String sql = "INSERT INTO clientes (nombre, email, telefono, direccion) VALUES (?,?,?,?)";
        PreparedStatement ps = con.prepareStatement(sql);

        for (int i = 1; i <= 50; i++) {
            ps.setString(1, "Cliente" + i);
            ps.setString(2, "cliente" + i + "@gmail.com");
            ps.setString(3, "676787879" + i);
            ps.setString(4, "Calle " + i);

            ps.addBatch();  // añadir al lote
        }

        ps.executeBatch(); // ejecutar lote completo
        System.out.println("50 clientes insertados.");
    }


    // INSERTAR 20 PRODUCTOS


    private static void insertarProductos(Connection con) throws SQLException {

        String sql = "INSERT INTO productos (nombre, precio, categoria) VALUES (?,?,?)";
        PreparedStatement ps = con.prepareStatement(sql);

        for (int i = 1; i <= 20; i++) {
            ps.setString(1, "Producto" + i);
            ps.setDouble(2, 10.0 + i);  // precio
            ps.setString(3, "Categoria" + i);

            ps.addBatch();
        }

        ps.executeBatch();
        System.out.println("20 productos insertados.");
    }


    // INSERTAR 60 PEDIDOS


    private static void insertarPedidos(Connection con) throws SQLException {

        String sql = "INSERT INTO pedidos (cliente_id, producto_id, cantidad, fecha) VALUES (?,?,?,?)";
        PreparedStatement ps = con.prepareStatement(sql);

        for (int i = 1; i <= 60; i++) {

            int clienteId = 1 + (int) (Math.random() * 50); // entre 1 y 50
            int productoId = 1 + (int) (Math.random() * 20); // entre 1 y 20

            ps.setInt(1, clienteId);
            ps.setInt(2, productoId);
            ps.setInt(3, 1 + (int) (Math.random() * 5)); // cantidad random 1–5
            ps.setDate(4, Date.valueOf("2024-01-01"));

            ps.addBatch();
        }

        ps.executeBatch();
        System.out.println("60 pedidos insertados.");
    }
}

