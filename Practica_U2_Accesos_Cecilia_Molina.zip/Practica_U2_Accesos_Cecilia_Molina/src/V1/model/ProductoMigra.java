package V1.model;

import java.math.BigDecimal;

public class ProductoMigra {

    private int id;
    private String nombre;
    private BigDecimal precio;
    private boolean migrado;

    public ProductoMigra(int id, String nombre, BigDecimal precio, boolean migrado) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.migrado = migrado;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public BigDecimal getPrecio() {
        return precio;
    }

    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }

    public boolean isMigrado() {
        return migrado;
    }

    public void setMigrado(boolean migrado) {
        this.migrado = migrado;
    }

    @Override
    public String toString() {
        return "ProductoMigra{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", precio=" + precio +
                ", migrado=" + migrado +
                '}';
    }
}
